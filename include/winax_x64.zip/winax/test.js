
// var winax = require('./build/Debug/node_activex.node');
var winax = require('./build/Release/node_activex.node');

/*
var obj = new winax.Object({
    test: function(v) { return v*2; }
});

var varr = new winax.Variant(obj, 'uint8[]');
var arr = new Uint8Array(varr.valueOf());
console.log(arr);

var obj2 = new winax.Object(arr);
console.log(obj2.test(2));
*/

/*
var anyvar = new winax.Variant(123, "int32");
for (var i = 0; i < 20000; i++) {
    // anyvar._value;
    anyvar.valueOf();
    // valueOf.call(anyvar);
    global.gc(); // --expose-gc paramterer required!!!!
    if (i % 100 == 0) console.log('step ' + i + ', heap used= ' + Math.round(process.memoryUsage().heapUsed / 1024) + ' KB')
}
//*/

// var test_value = 'wewewe'
// var js_obj = {
//     text: test_value,
//     obj: { params: test_value },
//     arr: [test_value, test_value, test_value],
//     func: function(v) { return v * 2; },
//     func2: function(obj) { return obj.text; }
// };

// var com_obj = new winax.Object(js_obj);
// if (com_obj.arr.length != js_obj.arr.length) {
//     console.log('err');
// }
// console.log('end: ' + com_obj.arr.length);



var word;
let doc = null;
try {
    // word = new winax.Object("KWPS.Application");
    word = new winax.Object("Word.Application");
    doc = word.documents.open("C:\\Temp\\1.docx")
    doc.TablesOfContents.Item(1).UpdatePageNumbers()
    let tables = doc.TablesOfContents;
    //let item = tables.Item;
    let table = tables(1);
    table.UpdatePageNumbers();
    doc.save();
} catch(e) {
    console.log('encoutered exception', e);
} finally {
    try {
        doc && doc.close();
    } catch(e){
        console.log('doc.close error');
    }

    try {
        word && word.quit();
    } catch(e){
        console.log('word.quit error');
    }

    try {
        word && winax.release(word);
    } catch(e){
        console.log('winax.release error');
    }
}